
import numpy as np
import abc
from .graph import Graph, default_graph
class Node(object):
    def __init__(self,*parents,**kargs):
        self.kargs = kargs
        self.graph = kargs.get('graph', default_graph)
        self.need_save = kargs.get('need_save', True)
        self.generate_node_name(**kargs)
        self.parents = list(parents)  # 父节点列表
        self.childrens = []  # 子节点列表
        self.value = None  # 本节点的值
        self.jacobi = None  # 结果节点对本节点的雅可比矩阵
        
        for parent in self.parents:###将本节点的地址添加至父节点的子节点，其实就是形成链表
            parent.childrens.append(self)
        self.graph.add_node(self)
    def get_parent(self):
        return self.parents
    
    def get_children(self):
        return self.childrens
    
    def generate_node_name(self,**kargs):
        self.name = kargs.get('name', '{}:{}'.format(
            self.__class__.__name__, self.graph.node_count()))
        if self.graph.name_scope:
            self.name = '{}/{}'.format(self.graph.name_scope, self.name)
            
    def forward(self):
        for node in self.parents:
            if node.value is None:
                node.forward()
        self.compute()

    @abc.abstractmethod
    def compute(self):
        """每个节点将重新定义该运算"""

    @abc.abstractmethod
    def get_jacobi(self,parent):
        """每个节点将重新定义 由子节点获得父节点雅克比矩阵的方法"""

    def clear_jacobi(self):
        self.jacobi=None

    def backward(self, result):
        """
        反向传播，计算结果节点对本节点的雅可比矩阵
        """
        if self.jacobi is None:
            if self is result:
                self.jacobi = np.mat(np.eye(self.dimension()))
            else:
                self.jacobi = np.mat(
                    np.zeros((result.dimension(), self.dimension())))

                for child in self.get_children():
                    if child.value is not None:
                        self.jacobi += child.backward(result) * child.get_jacobi(self)

        return self.jacobi

    def dimension(self):###将本节点的特征展平成一维之后的维数
        return self.value.shape[0]*self.value.shape[1]
    def shape(self):
        """
        返回本节点的值作为矩阵的形状：（行数，列数）
        """
        return self.value.shape
    def reset_value(self, recursive=True):
        """
        重置本节点的值，并递归重置本节点的下游节点的值
        """
        self.value = None
        if recursive:
            for child in self.childrens:
                child.reset_value()

class Variable(Node):
    def __init__(self, dim, init=False, trainable=True, **kargs):
        Node.__init__(self,  **kargs)

        self.dim = dim

        if init:
            self.value=np.mat(np.random.normal(0,0.01,self.dim))
        self.trainable = trainable

    def set_value(self, value):
        """
        为变量赋值
        """
        assert isinstance(value, np.matrix) and value.shape == self.dim

        # 本节点的值被改变，重置所有下游节点的值
        self.reset_value()
        self.value = value