from .node import Variable
from .graph import default_graph

def get_node_from_graph(node_name, name_scope=None, graph=None):
    if graph is None:
        graph=default_graph
    if name_scope:
        node_name = name_scope + '/' + node_name
        for node in graph.nodes:
            if node_name==node.name:
                return node
    return None

def get_trainable_variables_from_graph(node_name=None, name_scope=None, graph=None):
    if graph is None:
        graph=default_graph
    if node_name is None:
        return [node for node in graph.nodes if isinstance(node, Variable) and node.trainable ]
    if name_scope:
        node_name = name_scope + '/' + node_name
    return get_node_from_graph(node_name,graph=graph)


class name_scope(object):
    def __init__(self, name_scope):
        self.name_scope = name_scope

    def __enter__(self):
        default_graph.name_scope = self.name_scope
        return self

    def __exit__(self, exc_type, exc_value, exc_tb):
        default_graph.name_scope = None
