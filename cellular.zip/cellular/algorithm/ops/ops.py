import numpy as np
from ..core import Node

class Operator(Node):
    """此处定义操作符的抽象类"""

class Logistic(Operator):
    def compute(self):
        x=self.parents[0].value
        self.value=np.mat(1.0/(1.0+np.power(np.e,np.where(-x>1e2,1e2,-x))))
    def get_jacobi(self, parent):
        return np.diag(np.mat(np.multiply(self.value,1-self.value)).A1)

class Add(Operator):
    def compute(self):
        self.value=np.mat(np.zeros(self.parents[0].shape()))####????????
        for parent in self.parents:
            self.value+=parent.value
    def get_jacobi(self,parent):#??????????
        return np.mat(np.eye(self.dimension()))
    
class MatMul(Operator):
    def compute(self):
        assert len(self.parents) == 2 and \
               self.parents[0].shape()[1] == self.parents[1].shape()[0]
        self.value = self.parents[0].value * self.parents[1].value

    def get_jacobi(self, parent):
        """
        将矩阵乘法视作映射，求映射对参与计算的矩阵的雅克比矩阵。
        """

        # 很神秘，靠注释说不明白了
        zeros = np.mat(np.zeros((self.dimension(), parent.dimension())))
        if parent is self.parents[0]:
            return fill_diagonal(zeros, self.parents[1].value.T)
        else:
            jacobi = fill_diagonal(zeros, self.parents[0].value)
            row_sort = np.arange(self.dimension()).reshape(
                self.shape()[::-1]).T.ravel()
            col_sort = np.arange(parent.dimension()).reshape(
                parent.shape()[::-1]).T.ravel()
            return jacobi[row_sort, :][:, col_sort]
        
class Multiply(Operator):
    def compute(self):
        assert self.parents[0].shape()[0]==self.parents[1].shape()[0]
        self.value = np.multiply(self.parents[0].value, self.parents[1].value)
    def get_jacobi(self,parent):

        if parent is self.parents[0]:
            return np.diag(self.parents[1].value.A1)
        else:
            return np.diag(self.parents[0].value.A1)

class SoftMax(Operator):
    @staticmethod
    def softmax(x):
        x[x>1e2]=1e2
        bottom=np.power(np.e,x)
        return x/np.sum(bottom)
    def compute(self):
        self.value=SoftMax.softmax(self.parents[0].value)
        
    def get_jacobi(self,parent):
        """子类继承该方法以后再重用"""
        raise NotImplementedError("you should subclass this function")


def fill_diagonal(to_be_filled, filler):
    """
    将 filler 矩阵填充在 to_be_filled 的对角线上
    """
    assert to_be_filled.shape[0] / \
        filler.shape[0] == to_be_filled.shape[1] / filler.shape[1]
    n = int(to_be_filled.shape[0] / filler.shape[0])

    r, c = filler.shape
    for i in range(n):
        to_be_filled[i * r:(i + 1) * r, i * c:(i + 1) * c] = filler

    return to_be_filled

# class SoftMax(Operator):
#     def __init__(self):