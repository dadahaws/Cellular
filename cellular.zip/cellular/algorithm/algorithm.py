from . import core
# from . import dist
from . import optimizer
from . import ops

default_graph = core.default_graph
get_node_from_graph = core.get_node_from_graph
name_scope = core.name_scope
Variable = core.Variable