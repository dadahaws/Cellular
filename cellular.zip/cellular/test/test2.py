import numpy as np

x=np.mat(np.random.rand(1,1))
print(x.shape)