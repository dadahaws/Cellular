import numpy as np
import torch
a=np.random.rand(3,4)
print(a)
print(a.shape)
func=np.array(a).argmax(axis=0)
nums=[]
nums.append(np.array([-1,1]))
nums.append(np.array([2,-2]))
nums.append(np.array([3,3]))
nums=np.array(nums)
print(nums.shape)
print(nums)
slop=0.1
nums=np.mat(np.where(nums>0,nums,slop*nums))
print('ed',nums)
tmp1=np.mat(np.random.normal(0, 0.001,size=(5,5)))
print('tmp1',tmp1)
x=np.array([1,2,3,4,5])
diag=-1/(1+np.power(np.e,np.where(x>1e2,1e2,x)))
y=np.diag(diag.ravel())
print('x',x)
print('diag',diag)
print('y',y)
tmp=np.mat(np.multiply(x,1-x))
print('tmp',tmp.shape)
z=np.diag(np.mat(np.multiply(x,1-x)).A1)

print('z',z)
i=np.eye(9)
print('i',i)

v=[1,2,3,4,5,6]
v=np.mat(v)
print('v',v.shape[0])
print(v[0].shape[0])