import numpy as np
import sys
sys.path.append('../')
import algorithm as al
male_heights = np.random.normal(171, 6, 500)
female_heights = np.random.normal(158, 5, 500)

male_weights = np.random.normal(70, 10, 500)
female_weights = np.random.normal(57, 8, 500)

male_bfrs = np.random.normal(16, 2, 500)
female_bfrs = np.random.normal(22, 2, 500)

male_labels = [1] * 500
female_labels = [-1] * 500


train_set=np.array([
    np.concatenate((male_heights,female_heights)),
    np.concatenate((male_weights,female_weights)),
    np.concatenate((male_bfrs,female_bfrs)),
    np.concatenate((male_labels,female_labels))]).T
#print('train_set.shape',train_set.shape)
#print('train_set',train_set)

np.random.shuffle(train_set)

x=al.core.Variable(dim=(3,1),init=False,trainable=False)

label=al.core.Variable(dim=(1,1),init=False,trainable=False)
#
w=al.core.Variable(dim=(1,3),init=True,trainable=True)
#
b=al.core.Variable(dim=(1,1),init=True,trainable=True)

output=al.ops.Add(al.ops.MatMul(w,x),b)
predict=al.ops.Logistic(output)

loss=al.ops.loss.Logloss(al.ops.Multiply(label,output))


optimizer=al.optimizer.GradientDescent(al.default_graph,loss,learning_rate=0.001)

batch_size = 16

for epoch in range(20):

    # 每一轮批计数器清零
    batch_count = 0

    # 遍历训练集中的样本
    for i in range(len(train_set)):

        # 取第i个样本的前3列，构造3x1矩阵对象
        features = np.mat(train_set[i, :-1]).T

        # 取第i个样本的最后一列，是该样本的性别标签（1男，-1女），构造1x1矩阵对象
        l = np.mat(train_set[i, -1])

        # 将特征赋给x节点，将标签赋给label节点
        x.set_value(features)
        label.set_value(l)

        # 调用优化器的one_step方法，执行一次前向传播和反向传播
        optimizer.one_step()

        # 批计数器加1
        batch_count += 1

        # 若批计数器大于等于批大小，则执行一次更新，并清零计数器
        if batch_count >= batch_size:
            optimizer.update()
            batch_count = 0

    # 每个epoch结束后评估模型的正确率
    pred = []

    # 遍历训练集，计算当前模型对每个样本的预测值
    for i in range(len(train_set)):
        features = np.mat(train_set[i, :-1]).T
        x.set_value(features)

        # 在模型的predict节点上执行前向传播
        predict.forward()
        pred.append(predict.value[0, 0])  # 模型的预测结果：1男，0女

    # 将1/0结果转化成1/-1结果，好与训练标签的约定一致
    pred = (np.array(pred) > 0.5).astype(np.int) * 2 - 1

    # 判断预测结果与样本标签相同的数量与训练集总数量之比，即模型预测的正确率
    accuracy = (train_set[:, -1] == pred).astype(np.int).sum() / len(train_set)

    # 打印当前epoch数和模型在训练集上的正确率
    print("epoch: {:d}, accuracy: {:.3f}".format(epoch + 1, accuracy))

print('w的值',w.value)


